<?php

class Controller_login extends Controller
{
    function __construct()
    {
        $this->model = new Model_Login();
        $this->view = new View();
    }

    function action_index()
    {
        if(!$_SESSION["auth_ok"]) $this->view->generate("login_view.php", 'template_view.php');
        else header("Location: /login/personal",TRUE,301);
    }

    function action_personal()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$_SESSION["auth_ok"]) {
            $data = $this->model->Login($_POST['ml'], $_POST['pswrd']);
            if(!is_array($data))$this->view->generate('login_view.php', 'template_view.php', $data);
            else $this->view->generate('personal_view.php', 'template_view.php', $this->model->myData($data['username']));
        } elseif($_SESSION["auth_ok"])  $this->view->generate('personal_view.php', 'template_view.php', $this->model->myData());
        else header("Location: /login",TRUE,301);
    }
    function action_save()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION["auth_ok"]) {
            $data = $this->model->saveData($_POST);
            $this->view->generate('personal_view.php', 'template_view.php', $data);
        } elseif($_SESSION["auth_ok"])  $this->view->generate('personal_view.php', 'template_view.php', $this->model->myData());
        else header("Location: /login",TRUE,301);
    }
}
