<?php

class Controller_register extends Controller
{
    function __construct()
    {
        $this->model = new Model_Register();
        $this->view = new View();
    }

    function action_index()
    {
        if(!$_SESSION["auth_ok"]) {

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = $this->model->saveData($_POST);
                $this->view->generate("register_view.php", 'template_view.php', $data);
            } else $this->view->generate("register_view.php", 'template_view.php');
        }
        else header("Location: /login/personal",TRUE,301);
    }
}
