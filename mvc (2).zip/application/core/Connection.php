<?php

class Connection
{
    public function createSql()
    {
        $conn = new mysqli('localhost', "nmfuce26_test", "6HF&FEj*", "nmfuce26_test");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }
}
