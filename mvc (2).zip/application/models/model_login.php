<?php


class Model_Login extends Model
{
    function Login($mail, $pass)
    {
        $a = "Неверный логин или пароль";
        $b = "Вы успешно вошли как";
        $c = "Введите mail и пароль";
        $sql = (new Connection())->createSql();
        $query = "SELECT `password_hash`,`username` FROM `user` WHERE `email`='$mail' and `password_hash`=md5('$pass')";
        $result = $sql->query($query);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        if ($mail == null || $pass == null) {
            return $c;
        } else {
            $user_password = $row['password_hash'];
            if ($user_password == md5($pass)) {
                $user = $row['username'];
                $_SESSION["auth_ok"] = true;
                $_SESSION["auth_login"] = $user;
                return $row;
            } else {
                return $a;
            }
        }
    }
    function saveData($data)
    {
        $sql = (new Connection())->createSql();
        $id=$_SESSION['auth_login'];
        $query = "SELECT `email`, `username` FROM `user` WHERE `username`='$id'";
        $result = $sql->query($query);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        if (!empty($data['pswrd'])&&$data['pswrd']!=$data['pswrd2']) {
            return $row + ['error'=>'Вы указали новый пароль, но не ввели подтверждение пароля.'];
        } else {
            if(!empty($data['pswrd'])) $query="UPDATE `user` SET `username` = '".$data['name']."',`email` = '".$data['email']."',`password_hash` = '".md5($data['pswrd'])."' WHERE `user`.`username` = '".$id."';";
            else $query="UPDATE `user` SET `username` = '".$data['name']."',`email` = '".$data['email']."' WHERE `user`.`username` = '".$id."';";
            $sql->query($query);
            $id=$data['name'];
            $query = "SELECT `email`, `username` FROM `user` WHERE `username`='$id'";
            $result = $sql->query($query);
            $row = $result->fetch_array(MYSQLI_ASSOC);
            $user = $row['username'];
            $_SESSION["auth_ok"] = true;
            $_SESSION["auth_login"] = $user;
            return $row + ['error'=>'Изменения успешно сохранены'];
        }
    }

    function myData($id='')
    {
        $sql = (new Connection())->createSql();
        if(empty($id)) $id=$_SESSION['auth_login'];
        $query = "SELECT `email`, `username` FROM `user` WHERE `username`='$id'";
        $result = $sql->query($query);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        return $row;
    }

}
