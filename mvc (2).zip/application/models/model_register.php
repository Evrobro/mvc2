<?php


class Model_Register extends Model
{
    function saveData($data)
    {
        $sql = (new Connection())->createSql();
        if (!empty($data['pswrd'])&&$data['pswrd']!=$data['pswrd2']) {
            return ['error'=>'Вы указали пароль, но не ввели подтверждение пароля.'];
        } else {
            $query="INSERT INTO `user` (`username`, `email`, `password_hash`) VALUES ('".$data['name']."','".$data['email']."','".md5($data['pswrd'])."');";
            $sql->query($query);
            $id=$data['name'];
            $query = "SELECT `email`, `username` FROM `user` WHERE `username`='$id'";
            $result = $sql->query($query);
            $row = $result->fetch_array(MYSQLI_ASSOC);
            $user = $row['username'];
            $_SESSION["auth_ok"] = true;
            $_SESSION["auth_login"] = $user;
            header("Location: /login/personal",TRUE,301);
        }
    }

}
