<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php echo "Привет, друг " . $_SESSION['ml']; ?>
<form action="/login/save" method="post">
    <div style="display: flex;justify-content: center;flex-direction: column ; align-items: center;margin-top: 350px;">
        <input type="text" name="name" placeholder="имя" value="<?=$data['username']?>" style="padding: 5px; margin: 15px;">
        <input type="email" name="email" placeholder="mail" value="<?=$data['email']?>" style="padding: 5px; margin: 15px;">
        <input type="password" name="pswrd" placeholder="Пароль" style="padding: 5px;margin: 15px;">
        <input type="password" name="pswrd2" placeholder="Повторите пароль для изменения" style="padding: 5px;margin: 15px;">
        <input type="submit" style="margin: 15px;">
    </div>
    <div class="error" style="display: flex;justify-content: center;">
        <?php
        print $data['error'];
        ?>
    </div>
</form>
</body>
</html>

